import os

print(os.getcwd())

# changing directory
os.chdir(r"C:\Users\Admin\Desktop\SP24\CSD203\pygame\blackjack2")
print(os.getcwd())

# joining path
path = os.path.join(os.getcwd(), "CardGame-main")
print(path)

# printing all files/folders in the directory
print(os.listdir(path))

# create folder in the directory
os.chdir(path)
os.mkdir("hellobaby")

# remove a folder
# os.rmdir("hellobaby")

# rename a folder
# os.rename("hellobaby", "hellobaby2")
